DBSCAN4LBSN


Author: Yingjie Hu
Email: yjhu.geo@gmail.com


Overall description: This program takes location-based social network (LBSN) data (point data), and performs two operations. One is DBSCAN which clusters the input data based on density; the other is concave hull which constructs polygons from point clusters. 


To run this program: open a cmd line in the current folder, and execute: "java -jar DBSCAN4LBSN.jar". To increase the allocated memory size, use "java -jar -Xmx2G DBSCAN4LBSN.jar". You will need Java 1.8 to run this program.


Input of the program: Location-based social network data in CSV format. The input data must contain three fields: "recordID", "x", and "y". If the input data also contain the id of the user, then "userID" can also be included. A sample of the input data can be found in the folder "Input".


The output of the program: the output is a EsriJSON file (called "result.json" in the same folder) which can be converted into Shapefile using the tool "json to features" in ArcGIS Toolbox.  


Configuration file (config.json): This file is very important for running the program as it specifies the key parameters. Detailed explaination for each parameter can be found in the config.json file. The DBSCAN algorithm requires two parameters: eps and minPts, whose values may need to be specified through some statistical analysis. Note minPts can be either an absolute value or a percentage. The concave hull algorithm requires a parameter lambda: a larger lambda results in smoother polygons while a smaller lambda results in more complex polygons. If you have questions with the parameters, please send me an email.


The "Temp" folder: this folder stores some temporary files generated in the middle of the process, such as the preprocessed file as well as the clustered result. If you want to see the clustered result from DBSCAN, you can import the clustered data into ArcMap using the "add x y" tool.


Clustering based on users v.s. clustering based on points: one cool feature of this software package is that it allows you to cluster based on either social media users or the location points (note: the same user may post multiple social media records at the same or very close locations). To cluster based on the number of users, set the parameter "userIDIndex" in the "config.json" file as the corresponding column index of the user ID. In contrast, if you want the clusters to be formed based on only the number of points, you need to put -1 for "userIDIndex" (even if you also have user ids in your data).


